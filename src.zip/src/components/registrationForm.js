import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addUser } from '../services/api';

function RegistrationForm() {
  const { name, email, phone } = useSelector((state) => state);
  const dispatch = useDispatch();

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Aqui você pode adicionar a lógica para processar os dados do formulário
    console.log('Nome:', name);
    console.log('Email:', email);
    console.log('Telefone:', phone);
    // Reseta os campos do formulário
    await addUser(name,email,phone)


    dispatch({
      type: 'UPDATE_FORM',
      payload: {
        name: '',
        email: '',
        phone: ''
      }
    });



  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    dispatch({
      type: 'UPDATE_FORM',
      payload: {
        [name]: value
      }
    });
  };

  return (
    <div className='divForm'>
      <h2>Cadastro</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Nome:</label>
          <input
            type="text"
            id="name"
            name="name"
            className="form-control"
            value={name}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            className="form-control"
            value={email}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">Telefone:</label>
          <input
            type="text"
            id="phone"
            name="phone"
            className="form-control"
            value={phone}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">Enviar</button>
      </form>
    </div>
  );
}

export default RegistrationForm;