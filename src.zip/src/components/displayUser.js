import React from 'react';
import { useSelector } from 'react-redux';

function DisplayUser() {
  const { name, email, phone } = useSelector((state) => state);

  return (
    <div>
      <h2>Dados Salvos</h2>
      <p><strong>Nome:</strong> {name}</p>
      <p><strong>Email:</strong> {email}</p>
      <p><strong>Telefone:</strong> {phone}</p>
    </div>
  );
}

export default DisplayUser;
