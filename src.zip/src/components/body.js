import React from "react";
import Counter from "./counter/counter";


export default function Body() {
  return (
    <>
        <p>Body aqui vai ficar a rota</p>
        <Counter />
    </>
  );
}
