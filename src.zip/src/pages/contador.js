import React from "react";
import Body from "../components/body";

export default function Contador() {
    return (
        <>
            <h2>Componente Contador</h2>
            <Body />
        </>
    );
}