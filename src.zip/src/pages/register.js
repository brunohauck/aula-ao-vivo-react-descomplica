import React from 'react';
import DisplayUser from '../components/displayUser';
import RegistrationForm from '../components/registrationForm';

function Register() {
  return (
    <div>
      <h1>Corpo da Página</h1>
      <RegistrationForm />
      <DisplayUser />
    </div>
  );
}

export default Register;